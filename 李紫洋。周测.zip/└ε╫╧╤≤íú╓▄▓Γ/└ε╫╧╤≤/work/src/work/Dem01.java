package work;
//��99�˷��ھ�

public class Dem01 {

	public static void main(String[] args) {
		for (int num = 1; num <=9; num++) {
			for (int j = 1; j <=num; j++) {
				System.out.print(j+"*"+num+"="+j*num+"\t");	
			}
			
			System.out.println();//����
		}
		
	}

}
