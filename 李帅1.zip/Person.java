package test01;

public class Person {
	String name;
	int age;
	Person() {
		
	}
	Person(String name,int age){
		this.name=name;
		this .age=age;
	
	}
	void showMessage() {
		System.out.println("չʾĳ����Ϣ");
	}
}
