package tsxt1;

public class Person {
	String name;
	int age;
	Person(){
		
	}
	Person(String name,int age){
		
	}
	void showMessage() {
		System.out.println("չʾĳ�˵���Ϣ");
	}

}
