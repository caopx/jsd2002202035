package tsxt1;



public class Test {

	public static void main(String[] args) {
		Person[] ps =new Person[5];
		ps[0] = new Student("aaa",11,001);
		ps[1] = new Student("bbb",21,002);
		ps[2] = new Student("ccc",22,2);
		ps[3] = new Teacher("ddd",23,002);
		ps[4] = new Teacher("bbb",21,002);
		for (int i=0;i<ps.length;i++) {
			System.out.println(ps[i].name);
			ps[i].showMessage();
		}
	
	}

}
